<?php
    session_start();
    class Banco {
        public $conta;
        public $saldo;
    
        public function depositar($valor){
            if($valor >=10){
                $this->saldo += $valor;
            }
            else{
                echo "Valor inferior a R$10";
            }
        }
        public function sacar($valor){
            $this->saldo -=$valor;
        }
    }
?>