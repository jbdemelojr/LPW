<?php
    include("../bd/banco.php");
    class Cliente extends Banco {
        public $nome;
        public $cpf;
        private $possui_emprestimo = false;
        public $val_emp;

        public function emprestimo($valor) {
            if ($this->possui_emprestimo) {
                echo "<br>Cliente já possui empréstimo. Não é possível abrir outro empréstimo.<br>";
            } else {
                $this->possui_emprestimo = true;
                $this->depositar($valor);
                $this->val_emp = $valor;
            }
        }
        
        public function quitar_emprestimo($valor_quitacao) {
            if (!$this->possui_emprestimo) {
                echo "O cliente não possui empréstimo pendente.<br>";
            } elseif ($valor_quitacao != $this->val_emp) {
                echo "Valor de quitação incorreto. O valor correto é R$".$this->val_emp."<br>";
            } else {
                $this->saldo -= $valor_quitacao;
                $this->possui_emprestimo = false;
                echo "Empréstimo quitado. Saldo atual: R$".$this->saldo."<br>";
                $this->emprestimo(5000); 
            }
        }
    }

    $pessoa = new Cliente();
    $pessoa->nome = "Jose";
    $pessoa->cpf = "45297467542";
    $pessoa->saldo = 1000;
    $pessoa->depositar(800);

    echo "O saldo atual de " . $pessoa->nome . " é R$" . $pessoa->saldo . "<br>";

    $pessoa->emprestimo(7000);

    echo "O saldo atual de " . $pessoa->nome . " é R$" . $pessoa->saldo . "<br>";

    $pessoa->quitar_emprestimo(800); 
    
    $pessoa->quitar_emprestimo(7000);

    echo "O saldo atual de " . $pessoa->nome . " é R$" . $pessoa->saldo . "<br>";
?>
